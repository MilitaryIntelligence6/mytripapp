//
//  DetailTableViewCell.h
//  BDVRClientDemo
//
//  Created by baidu on 16/3/15.
//  Copyright © 2016年 baidu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailTableViewCell : UITableViewCell

- (void)setDetailTitle:(NSString *)title;

@end
