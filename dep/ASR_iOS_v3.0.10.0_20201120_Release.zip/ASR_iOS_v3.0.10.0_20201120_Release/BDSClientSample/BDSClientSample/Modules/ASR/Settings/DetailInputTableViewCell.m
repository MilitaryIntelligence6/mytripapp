//
//  DetailInputTableViewCell.m
//  BDVRClientDemo
//
//  Created by baidu on 16/3/15.
//  Copyright © 2016年 baidu. All rights reserved.
//

#import "DetailInputTableViewCell.h"

@implementation DetailInputTableViewCell

@end
