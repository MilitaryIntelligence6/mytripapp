//
//  DetailTableViewController.h
//  BDVRClientDemo
//
//  Created by baidu on 16/3/15.
//  Copyright © 2016年 baidu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BDVRSettingsItem.h"

@interface DetailTableViewController : UITableViewController

@property (nonatomic, strong) BDVRSettingsItem *settingsItem;

@end
