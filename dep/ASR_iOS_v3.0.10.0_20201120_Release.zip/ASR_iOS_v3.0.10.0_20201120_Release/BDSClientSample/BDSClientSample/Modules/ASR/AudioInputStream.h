//
//  AudioInputStream.h
//  BDVRClientDemo
//
//  Created by baidu on 16/6/17.
//  Copyright © 2016年 baidu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AudioInputStream : NSInputStream

@end
